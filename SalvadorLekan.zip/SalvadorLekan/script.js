const TOD = document.getElementById("tod")
const intro = document.getElementById("intro")
var date = new Date().getHours()
if (date< 12) {
    TOD.innerText= "Morning"
}else if (date<17) {
    TOD.innerText="Afternoon"
}else {
    TOD.innerText="Evening"
}
function setAct (evt) {
    var i, tablinks;
  
    tablinks = document.getElementsByClassName("tab-links");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace("active", "");
    }
  
    // add an "active" class to the button that opened the tab
    evt.currentTarget.className += " active";
  }
  var introVal= intro.innerText;
  var introVal= introVal.split("")
  var count= 0
  var newVal = []
  var dd= setInterval(myy,100)
  function myy(){
    if (count <introVal.length){  newVal.push(introVal[count])
      count+=1
      intro.innerText=newVal.join("")}else{clearInterval(dd)}
  }